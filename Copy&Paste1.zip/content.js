// content.js
(() => {
  // Unblock common site restrictions (capture phase so site code can't stop us)
  const blockTypes = ["copy","cut","paste","contextmenu","selectstart","keydown","keyup","dragstart","beforeinput"];
  const stopper = (e) => {
    // Don't let page handlers cancel or rewrite clipboard events
    e.stopPropagation();
  };
  blockTypes.forEach((t) => {
    window.addEventListener(t, stopper, true);
    document.addEventListener(t, stopper, true);
  });

  // Clear inline handlers if present
  document.addEventListener("DOMContentLoaded", () => {
    try {
      document.onpaste = document.oncopy = document.oncut = document.oncontextmenu = null;
      if (document.body) {
        document.body.onselectstart = null;
        document.body.style.userSelect = "text";
        document.body.style.webkitUserSelect = "text";
      }
    } catch {}
  });

  // Listen for paste command from background/popup
  chrome.runtime.onMessage.addListener(async (msg) => {
    if (msg && msg.type === "pasteFromPanel") {
      pastePanelTextIntoFocused();
    }
  });

  async function pastePanelTextIntoFocused() {
    try {
      const active = document.activeElement;
      if (!active) return;
      const { panelText = "" } = await chrome.storage.sync.get("panelText");
      const text = panelText || "";
      if (!text) return;

      // Try to enable typing if the site disabled things
      try {
        active.removeAttribute("readonly");
        active.removeAttribute("disabled");
      } catch {}

      // Insert based on element type
      const tag = (active.tagName || "").toLowerCase();
      if (tag === "input" || tag === "textarea") {
        const start = active.selectionStart ?? active.value.length;
        const end = active.selectionEnd ?? active.value.length;
        const v = active.value || "";
        active.value = v.slice(0, start) + text + v.slice(end);
        const pos = start + text.length;
        active.selectionStart = active.selectionEnd = pos;
        active.dispatchEvent(new Event("input", { bubbles: true }));
        return;
      }

      if (active.isContentEditable) {
        try {
          // Range-based insert keeps exact tabs/newlines
          const sel = window.getSelection();
          if (sel && sel.rangeCount) {
            const range = sel.getRangeAt(0);
            range.deleteContents();
            range.insertNode(document.createTextNode(text));
            range.collapse(false);
          } else {
            document.execCommand("insertText", false, text);
          }
        } catch {
          document.execCommand("insertText", false, text);
        }
        return;
      }

      // Fallback: try to focus a possible editor
      const editable = document.querySelector('textarea, input[type="text"], [contenteditable="true"]');
      if (editable) {
        editable.focus();
        const tag2 = editable.tagName ? editable.tagName.toLowerCase() : "";
        if (tag2 === "input" || tag2 === "textarea") {
          const v2 = editable.value || "";
          editable.value = v2 + text;
          editable.dispatchEvent(new Event("input", { bubbles: true }));
        } else if (editable.isContentEditable) {
          document.execCommand("insertText", false, text);
        }
      }
    } catch (err) {
      console.warn("Paste from panel failed:", err);
    }
  }
})();